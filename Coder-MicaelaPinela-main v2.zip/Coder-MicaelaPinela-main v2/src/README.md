# Tercer Preentrega

## Curso

- Curso de Python
- Comisión N° 60095
- Profesor Esteban Acevedo

## Alumno

- Nombre: Micaela Pinela

## Objetivos del proyecto

- 1° Crear un proyecto WEB Django para una pastelería que permita crear productos, clientes y tomar pedidos
- 2° Generar 3 modelos: Clientes, productos y pedidos
- 3° Generar formularios para crear el contenido de clientes, productos y pedidos 

## Aspectos técnicos

He utilizado django, he creado 3 modelos (clientes, productos, pedidos) en la aplicación Planet Bakery

## Puntos a mejorar

- 1°
- 2°