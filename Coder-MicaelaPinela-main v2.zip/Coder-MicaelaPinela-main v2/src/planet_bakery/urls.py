
from django.urls import path

from .views import (
    about, 
    index, 
    cliente_list, 
    producto_list, 
    pedido_list, 
    cliente_create, 
    producto_create, 
    pedido_create,
    )

app_name = "planet_bakery"

urlpatterns = [
    path("", index, name="index"),
    path("about/", about, name="about" ),
    path("cliente/list/", cliente_list, name="cliente_list"),
    path("cliente/create/", cliente_create, name="cliente_create"),
    path("producto/list/", producto_list, name="producto_list"),
    path("producto/create/", producto_create, name="producto_create"),
    path("pedido/list/", pedido_list, name="pedido_list"),
    path("pedido/create/", pedido_create, name="pedido_create"),
]