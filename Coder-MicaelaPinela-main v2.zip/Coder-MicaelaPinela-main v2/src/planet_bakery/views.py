from django.shortcuts import redirect, render
from .models import Cliente, Producto, Pedido
from .forms import ClienteForm, ProductoForm, PedidoForm

def index(request):
    return render(request, 'planet_bakery/index.html')

def about (request):
    return render(request, 'planet_bakery/about.html')

def cliente_list(request):
    query = Cliente.objects.all()
    context = {"object_list": query}
    return render(request, "planet_bakery/cliente_list.html", context)

def cliente_create(request):
    if request.method == "GET":
        form = ClienteForm()
    if request.method == "POST":
        form = ClienteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("planet_bakery:cliente_list")
    return render(request, "planet_bakery/cliente_form.html", {"form": form})

def producto_list(request):
    query = Producto.objects.all()
    context = {"object_list": query}
    return render(request, "planet_bakery/producto_list.html", context)

def producto_create(request):
    if request.method == "GET":
        form = ProductoForm
    if request.method == "POST":
        form = ProductoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("planet_bakery:producto_list")
    return render(request, "planet_bakery/producto_form.html", {"form": form})

def pedido_list(request):
    query = Pedido.objects.all()
    context = {"object_list": query}
    return render(request, "planet_bakery/pedido_list.html", context)

def pedido_create(request):
    if request.method == "GET":
        form = PedidoForm
    if request.method == "POST":
        form = PedidoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("planet_bakery:pedido_list")
    return render(request, "planet_bakery/pedido_form.html", {"form": form})