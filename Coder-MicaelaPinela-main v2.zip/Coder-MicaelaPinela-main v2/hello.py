def main():
    print("Hello from coder-micaelapinela-main!")


if __name__ == "__main__":
    main()
